package info.androidhive.barcodereader;

public class device {
    String SeraialNumber;
    String Class;



    public void setSeraialNumber(String seraialNumber) {
        SeraialNumber = seraialNumber;
    }

    public void setClass(String aClass) {
        Class = aClass;
    }
}
