package info.androidhive.barcodereader;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class ScanActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan);

        Button clear = findViewById(R.id.button3);
        clear.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                if (true){
                    Toast.makeText(ScanActivity.this, "Welcome", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(ScanActivity.this, LoginActivity.class);
                    startActivity(intent);
                }
                else
                    Toast.makeText(ScanActivity.this, "uncorrect e-mail or password", Toast.LENGTH_SHORT).show();
            }
        });

    }
}
