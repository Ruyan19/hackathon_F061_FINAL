package info.androidhive.barcodereader;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class LoginActivity extends AppCompatActivity {

    // Declaring layout button, edit texts
    ProgressBar progressBar;
    // End Declaring layout button, edit texts
    // Declaring connection variables
    Connection connect;
    String DBUserNameStr, DBPasswordStr, db, ip, UserIDStr, PasswordStr;

    final EditText paa = findViewById(R.id.pass);

    final EditText mail = findViewById(R.id.mail);



    public void perform_action(View v){

        Intent intent =  new Intent(LoginActivity.this, MainActivity.class);
        startActivity(intent);

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        TextView create = findViewById(R.id.createUser);


        Button start = findViewById(R.id.button2);


        start.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                if (true){
                    Toast.makeText(LoginActivity.this, "Welcome", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(LoginActivity.this, ScanActivity.class);
                    startActivity(intent);
                }
                else
                    Toast.makeText(LoginActivity.this, "uncorrect e-mail or password", Toast.LENGTH_SHORT).show();
            }
        });


        // Getting values from button, texts and progress bar
        // End Getting values from button, texts and progress bar

        // Declaring Server ip, username, database name and password
        ip ="192.168.127.1:1433";
        db ="sparkleDB";
        DBUserNameStr ="rawan";
        DBPasswordStr ="rawan";
        //Declaring Server ip, username, database name and password
        progressBar.setVisibility(View.GONE);
        start.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

            }
        });



    }



    public void onClick(View v) {

        UserIDStr =mail.getText().toString();
        PasswordStr =paa.getText().toString();

        //SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(Login.this);
        SharedPreferences prefs = getSharedPreferences("Booking", MODE_PRIVATE);
        prefs.edit().putString("user_id", UserIDStr).commit();

        checklogin check_Login = new checklogin();// this is the Asynctask, which is used to process in background to reduce load on app process
        check_Login.execute(UserIDStr, PasswordStr);


    }



    public class checklogin extends AsyncTask<String, String, String> {
        String ConnectionResult = "";
        Boolean isSuccess = false;

        @Override
        protected void onPreExecute() {

            progressBar.setVisibility(View.VISIBLE);

        }

        @Override
        protected void onPostExecute(String result) {
            progressBar.setVisibility(View.GONE);
            Toast.makeText(LoginActivity.this, result, Toast.LENGTH_SHORT).show();
            if (isSuccess) {
                Intent intent = new Intent(LoginActivity.this, ScanActivity.class);
                startActivity(intent);

            }
        }


        protected String doInBackground(String... params) {
            String userid = UserIDStr;
            String passwordd = PasswordStr;
            if (userid.trim().equals("") || passwordd.trim().equals(""))
                ConnectionResult = "Please enter Username and Password";
            else {

                try {
                    ConnectionStr conStr = new ConnectionStr();

                    connect = conStr.connectionclasss();        // Connect to database
                    if (connect == null) {
                        ConnectionResult = "Check Your Internet Access!";
                    } else {


                        String query = "select * from dbo.account where name = '" + userid.toString() + "' and password = '" + passwordd.toString() + "'  ";
                        Statement stmt = connect.createStatement();
                        ResultSet rs = stmt.executeQuery(query);
                        if (rs.next()) {
                            ConnectionResult = "Login successful";
                            isSuccess = true;

                        } else {
                            ConnectionResult = "Invalid Credentials!";
                            isSuccess = false;
                        }
                    }
                } catch (Exception ex) {
                    isSuccess = false;
                    ConnectionResult = ex.getMessage();
                }
            }
            return ConnectionResult;
        }
    }

    boolean doubleBackToExitPressedOnce = false;

    @Override
    public void onBackPressed() {
        finish();
        return;


    }
}
