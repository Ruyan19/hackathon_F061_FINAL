package info.androidhive.barcodereader;

import android.annotation.SuppressLint;
import android.os.StrictMode;
import android.util.Log;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionClass {
 // String ip = "192.168.1.190:1433";
    String db = "BarcodeAPP";
    String un = "Barcodeuser";
    String password = "BBuser_2018";
   // String instance = "BARCODEAPP";

  String ip = "10.2.14.84:1433";
   // String ip = "10.21.15.83:5000";
   //String ip = "192.168.8.100:1433";


    @SuppressLint("NewApi")
    public Connection CONN()
    {
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        Connection connection = null;
        String connectionURL = null;
        try
        {
            Class.forName("net.sourceforge.jtds.jdbc.Driver");
            /*String connString="jdbc:jtds:sqlserver://192.168.1.104:1433/database_name;encrypt=false;user=sa;password=1234567890;integratedSecurity=true;instance=BARCODEAPP;";
            String username="sa";
            String password="1234567890";
            connection =DriverManager.getConnection(connString);*/
           // connectionURL =  "jdbc:jtds:sqlserver://191.168.1.100:1433;instanceName=BARCODEAPP;"

                //    + "databaseName=BarcodeAPP;integratedSecurity=true;user=webapp1;password=my_123;";
           connectionURL = "jdbc:jtds:sqlserver://" + ip + "/"+ db + ";user=" + un+ ";password=" + password + ";";
           connection = DriverManager.getConnection(connectionURL);
        }
        catch (SQLException se)
        {
            Log.e("error here 1 : ", se.getMessage());
        }
        catch (ClassNotFoundException e)
        {
            Log.e("error here 2 : ", e.getMessage());
        }
        catch (Exception e)
        {
            Log.e("error here 3 : ", e.getMessage());
        }
        return connection;
    }
}
